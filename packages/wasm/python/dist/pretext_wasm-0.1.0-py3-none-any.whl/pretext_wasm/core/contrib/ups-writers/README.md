University of Puget Sound's "Writer's Handbook"
===============================================

Compatibility layers to support extra features for discussing aspects of writing.

* Different styles of underlining.
* Colors to indicate parts of bibliography entries.
* A different ellipsis for text use.

First used Fall 2016.  None of this should be taken as especially semantic, so is not a good example of the PreTeXt philosophy.
