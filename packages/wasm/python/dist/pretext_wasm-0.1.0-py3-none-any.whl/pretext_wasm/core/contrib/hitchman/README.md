Hitchman's Linear Algebra Workbook
==================================

Compatibility layers to support TJ Hitchman's Linear Algebra workbook for his IBL course.

First used Fall 2014.  Principally a new "Task" environment was added.  But with the addition of a `task` element, and its subsequent re-purposing in Summer 2017, that code has been removed.
